-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jun 28, 2013 at 02:31 AM
-- Server version: 5.0.45
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `taskmanager`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `activities`
-- 

CREATE TABLE `activities` (
  `project_id` int(11) NOT NULL,
  `performed_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `action` varchar(150) NOT NULL,
  `username` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `activities`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `comments`
-- 

CREATE TABLE `comments` (
  `topic_id` int(20) NOT NULL,
  `comment` varchar(500) NOT NULL,
  `username` varchar(20) NOT NULL,
  `time` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `project_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `comments`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `invites`
-- 

CREATE TABLE `invites` (
  `project_id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `post` varchar(4) NOT NULL,
  `conf_code` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `invites`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `projects`
-- 

CREATE TABLE `projects` (
  `project_id` int(20) NOT NULL auto_increment,
  `title` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  `admin` varchar(20) NOT NULL,
  `leader` varchar(20) default NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `developers` varchar(200) default NULL,
  PRIMARY KEY  (`project_id`),
  UNIQUE KEY `title` (`title`,`admin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `projects`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `tasks`
-- 

CREATE TABLE `tasks` (
  `project_id` int(20) NOT NULL,
  `created_by` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `task_title` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `assigned_to` varchar(100) default NULL,
  `deadline` date default NULL,
  `task_id` int(20) NOT NULL auto_increment,
  PRIMARY KEY  (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `tasks`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `temp_users`
-- 

CREATE TABLE `temp_users` (
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `conf_code` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `company` varchar(100) NOT NULL,
  `time` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `temp_users`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `topics`
-- 

CREATE TABLE `topics` (
  `project_id` int(20) NOT NULL,
  `topic_id` int(20) NOT NULL auto_increment,
  `topic` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `username` varchar(20) NOT NULL,
  PRIMARY KEY  (`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `topics`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

CREATE TABLE `users` (
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `company` varchar(100) NOT NULL,
  `profile_pic` varchar(100) NOT NULL default 'profile.png',
  PRIMARY KEY  (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `users`
-- 

